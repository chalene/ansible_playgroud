Given("Open the browser") do
  #pending # Write code here that turns the phrase above into concrete actions
  #puts "Success"
  fail "Failed"
end
